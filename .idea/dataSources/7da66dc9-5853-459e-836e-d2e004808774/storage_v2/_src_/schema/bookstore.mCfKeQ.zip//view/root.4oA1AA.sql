create view root as
  select `bookstore`.`logistics`.`id`     AS `id`,
         `bookstore`.`orders`.`stats`     AS `stats`,
         `bookstore`.`orders`.`pay`       AS `pay`,
         `bookstore`.`book`.`bookname`    AS `bookname`,
         `bookstore`.`book`.`ISBN`        AS `ISBN`,
         `bookstore`.`book`.`price`       AS `price`,
         `bookstore`.`logistics`.`send`   AS `send`,
         `bookstore`.`logistics`.`take`   AS `take`,
         `bookstore`.`user`.`username`    AS `username`,
         `bookstore`.`orders`.`telephone` AS `telephone`,
         `bookstore`.`orders`.`address`   AS `address`,
         `bookstore`.`logistics`.`place1` AS `place1`,
         `bookstore`.`logistics`.`place2` AS `place2`,
         `bookstore`.`logistics`.`place3` AS `place3`,
         `bookstore`.`logistics`.`place4` AS `place4`,
         `bookstore`.`logistics`.`place5` AS `place5`,
         `bookstore`.`logistics`.`place6` AS `place6`,
         `bookstore`.`logistics`.`place7` AS `place7`,
         `bookstore`.`logistics`.`place8` AS `place8`,
         `bookstore`.`logistics`.`place9` AS `place9`
  from (((`bookstore`.`orders` left join `bookstore`.`logistics` on ((`bookstore`.`orders`.`id` =
                                                                      `bookstore`.`logistics`.`id`))) left join `bookstore`.`user` on ((
    `bookstore`.`user`.`username` = `bookstore`.`orders`.`buyer`))) left join `bookstore`.`book` on ((
    `bookstore`.`book`.`ISBN` = `bookstore`.`orders`.`book`)));

