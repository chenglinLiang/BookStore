create view books as
  select `bookstore`.`book`.`bookname` AS `bookname`,
         `bookstore`.`book`.`writer`   AS `writer`,
         `bookstore`.`book`.`ISBN`     AS `ISBN`,
         `bookstore`.`book`.`publish`  AS `publish`,
         `bookstore`.`book`.`price`    AS `price`,
         `bookstore`.`book`.`discount` AS `discount`,
         `bookstore`.`book`.`contents` AS `contents`
  from `bookstore`.`book`;

