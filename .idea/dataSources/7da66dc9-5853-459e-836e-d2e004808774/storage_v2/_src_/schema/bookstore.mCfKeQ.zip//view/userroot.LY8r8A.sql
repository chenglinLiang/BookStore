create view userroot as
  select `bookstore`.`user`.`username`  AS `username`,
         `bookstore`.`orders`.`id`      AS `id`,
         `bookstore`.`orders`.`stats`   AS `stats`,
         `bookstore`.`orders`.`pay`     AS `pay`,
         `bookstore`.`book`.`bookname`  AS `bookname`,
         `bookstore`.`book`.`ISBN`      AS `ISBN`,
         `bookstore`.`book`.`price`     AS `price`,
         `bookstore`.`logistics`.`send` AS `send`,
         `bookstore`.`logistics`.`take` AS `take`
  from `bookstore`.`user`
         join `bookstore`.`book`
         join `bookstore`.`orders`
         join `bookstore`.`logistics`
  where ((`bookstore`.`user`.`username` = `bookstore`.`orders`.`buyer`) and
         (`bookstore`.`orders`.`book` = `bookstore`.`book`.`ISBN`) and
         (`bookstore`.`orders`.`id` = `bookstore`.`logistics`.`id`) and (`bookstore`.`user`.`username` <> 'root') and
         (`bookstore`.`user`.`username` <> 'fast'));

