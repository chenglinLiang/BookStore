create view userbuy as
  select `bookstore`.`buy`.`username`     AS `username`,
         `bookstore`.`orders`.`telephone` AS `telephone`,
         `bookstore`.`book`.`bookname`    AS `bookname`,
         `bookstore`.`book`.`ISBN`        AS `ISBN`,
         `bookstore`.`book`.`writer`      AS `writer`
  from `bookstore`.`user`
         join `bookstore`.`book`
         join `bookstore`.`orders`
         join `bookstore`.`buy`
  where ((`bookstore`.`orders`.`id` = `bookstore`.`buy`.`id`) and
         (`bookstore`.`orders`.`book` = `bookstore`.`book`.`ISBN`));

