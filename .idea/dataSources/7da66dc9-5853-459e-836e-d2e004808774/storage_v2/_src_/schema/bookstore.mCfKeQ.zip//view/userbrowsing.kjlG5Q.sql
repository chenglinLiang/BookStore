create view userbrowsing as
  select `bookstore`.`browsing`.`username` AS `username`,
         `bookstore`.`orders`.`telephone`  AS `telephone`,
         `bookstore`.`book`.`bookname`     AS `bookname`,
         `bookstore`.`browsing`.`ISBN`     AS `ISBN`,
         `bookstore`.`book`.`writer`       AS `writer`
  from `bookstore`.`book`
         join `bookstore`.`orders`
         join `bookstore`.`browsing`
  where (`bookstore`.`orders`.`book` = `bookstore`.`book`.`ISBN`);

